﻿Console.Write("Введите ваше имя: ");
string username = Console.ReadLine();
Console.Write("Hello, ");
Console.WriteLine(username);