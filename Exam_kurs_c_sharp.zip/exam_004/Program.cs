﻿double numberA = 12;
double numberB = 5;
double result = numberA / numberB;
Console.WriteLine(result);